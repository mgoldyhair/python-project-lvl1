#!/usr/bin/env python

from brain_games.cli import welcome_user
from brain_games.cli import main

main()
welcome_user()


  

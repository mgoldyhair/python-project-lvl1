from brain_games.games.logic import name
from brain_games.games.logic import hello, congrats
from brain_games.games.brain_prime import brain_prime

def main():
    hello()
    brain_prime()
    congrats()


if __name__ == '__main__':
    main()
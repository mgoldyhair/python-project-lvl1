from brain_games.games.brain_progression import brain_progression
from brain_games.games.logic import hello, congrats

def main():
    hello()
    brain_progression()
    congrats()

    

if __name__ == '__main__':
    main()